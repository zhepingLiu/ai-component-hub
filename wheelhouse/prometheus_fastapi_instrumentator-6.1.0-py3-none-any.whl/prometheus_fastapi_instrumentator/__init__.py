from .instrumentation import PrometheusFastApiInstrumentator

__version__ = "6.1.0"

Instrumentator = PrometheusFastApiInstrumentator
